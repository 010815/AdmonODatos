import pickle

nombre = "Maria"

apellido = "Amador"

edad = 21

soltera = "true"

salario = 2689.50


registro = [nombre,apellido,edad,soltera,salario]

archivo = open("unArchivoDeMaria","wb")

pickle.dump(registro,archivo)

archivo.close()