import pickle 
#Abre archivo binario para leer(r) binario (b)
archivo = open("unarchivocualquiera.xcosa","rb")

#carga datos desde archivo
datos = pickle.load(archivo)

#muestra los datos
print(datos)

#cierra archivo
archivo.close()