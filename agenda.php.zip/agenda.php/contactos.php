<!DOCTYPE html>
<html lagn="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content ="width=device-width, initial-scale=1.0">

    <!-- -->
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/estilos.css">
    <tittle>Contactos</tittle>
</head>
<body>
    <!--Script php que empieza a configurar la pagina de los datos de la agenda -->
    <?php
    $nombreArchivo ="agenda.csv";
    $archivo = fopen($nombreArchivo, "r") or die ("No se puede abrir el archivo: $nombreArchivo");
    $datos = array();
    ?>
    <div class="container">
        <h1 class="titutlo">Contactos</h1>
        <!-- encerramos la tabla de otro contenedor especial para poder manipularla con un scroll horizontal -->e
        <div class="table-responsive">
            <table class="table">
                <!-- Encabezado de tabla-->
                 <thead class="table">
                     <tr><!-- diseño del renglon de encabezado-->
                        <th># de contactos</th>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Fecha de nacimiento</th>
                        <th>Estado civil</th>
                        <th>Origen</th>
                        <th>Email</th>
                        <th>Redes sociales</th>
                    </tr>
                <thead> <!--Termina encabezado de tabla -->
                <!-- cuerpo de la tabla-->
                <tbody>
                    <!-- Script para ir mostrando los contactos en la pagina-->
                    <?php
                    //recorramos la agenda
                    while (($datos= fgetcsv($archivo, 0, ',','"','"')) !== false){
                        //imprimimos el inicio del renglon de tabla HTML
                        print("<tr>");
                        foreach($datos as $campo) {
                            //imprimimos el inicio de la celda de datos HTML
                        print("<td>");
                        //imprimimos el dato
                        print("$campo");
                        //cerramos al celda HTML
                        print("</td>");
                        }
                        //cerramos el renglon de tabla HTML
                        print("</tr>");
                    }
                    ?>

                </tbody> <!-- Termina cuerpo tabla -->
            </table> <!-- Termina la  tabla -->
        </div>
    </div>
</body>
</html>
                


